# BIS 15L Repository

Welcome! This repository includes all of the .rmd files and data that we will use in class. Be sure to clone this to your desktop and keep it updated.  

## Contact Info

[Joel Ledford](mailto:jmledford@ucdavis.edu)  

## Class Links  

[BIS 15L Webpage](https://jmledford3115.github.io/datascibiol/)  
[BIS15-W21-DataScienceBiologists](https://github.com/jmledford3115/BIS15L-W21-DataScienceBiologists)  
[College of Biological Sciences](https://biology.ucdavis.edu/)  

## Thank You!  

Don't forget to leave a ⭐ if you found this useful.